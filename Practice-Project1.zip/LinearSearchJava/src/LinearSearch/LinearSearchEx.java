package LinearSearch;

public class LinearSearchEx {
	 public static int linearSearch(int[] arr, int target) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; // Return the index where the target element is found
	            }
	        }
	        return -1; // Return -1 if the target element is not found
	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {5, 2, 9, 1, 7, 4, 6, 3};
        int target = 7;

        int result = linearSearch(arr, target);
        if (result == -1) {
            System.out.println("Element not found");
        } else {
            System.out.println("Element found at index " + result);
        }
    }

	}


