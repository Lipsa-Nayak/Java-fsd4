package mergeSort;

public class MergeSortEx {
	  public static void main(String[] args) {
	        int[] array = {9, 5, 7, 3, 1, 8, 6, 2, 4};
	        System.out.println("Original array:");
	        printArray(array);

	        mergeSort(array);

	        System.out.println("Sorted array:");
	        printArray(array);
	    }

	    private static void printArray(int[] array) {
		// TODO Auto-generated method stub
		
	}

		public static void mergeSort(int[] array) {
	        if (array.length <= 1) {
	            return;
	        }

	        int middle = array.length / 2;
	        int[] left = new int[middle];
	        int[] right = new int[array.length - middle];

	        // Populate the left and right arrays
	        for (int i = 0; i < middle; i++) {
	            left[i] = array[i];
	        }
	        for (int i = middle; i < array.length; i++) {
	            right[i - middle] = array[i];
	        }

	        mergeSort(left);
	        mergeSort(right);
	        merge(left, right, array);
	    }

	    public static void merge(int[] left, int[] right, int[] result) {
	        int i = 0; // Index for the left array
	        int j = 0; // Index for the right array
	        int k = 0; // Index for the merged array

	        while (i < left.length && j < right.length) {
	            if (left[i] <= right[j]) {
	                result[k] = left[i];
	                i++;
	            } else {
	                result[k] = right[j];
	                j++;
	            }
	            k++;
	        }
}
}
